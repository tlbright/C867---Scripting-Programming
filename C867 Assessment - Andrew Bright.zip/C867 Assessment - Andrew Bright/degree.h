#ifndef DEGREE_H
#define DEGREE_H

#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <stdexcept>
using namespace std;


enum DegreeProgram {SECURITY, NETWORK, SOFTWARE};
static const char * degreeType[] = { "SECURITY", "NETWORK", "SOFTWARE" };



#endif // !DEGREE_H